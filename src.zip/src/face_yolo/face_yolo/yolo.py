import cv2
from ultralytics import YOLO

# Load the pre-trained Haar Cascade model for face detection
#face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Load the YOLO model
yolo = YOLO('yolov8s.pt')  # Ensure you have the YOLOv8 model file

# Load the video capture
videoCap = cv2.VideoCapture(0)

while True:
    ret, frame = videoCap.read()
    if not ret:
        continue

    # Convert the frame to grayscale for Haar Cascade face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces using Haar Cascade
    #faces_haar = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    # Detect objects using YOLO
    results = yolo(frame)

    # Iterate over each detected face from Haar Cascade
    #for (x, y, w, h) in faces_haar:
        # Draw a rectangle around the face
        #cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
        # Put the label "Face (Haar)" on the image
        #cv2.putText(frame, 'Face (Haar)', (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

    # Iterate over each detected object from YOLO
    for result in results:
        for box in result.boxes:
            if box.conf[0] > 0.4:  # Check if confidence is greater than 40%
                [x1, y1, x2, y2] = box.xyxy[0]
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                cls = int(box.cls[0])
                class_name = result.names[cls]

                if class_name == 'person':  # Assuming YOLO detects faces as 'person'
                    # Draw a rectangle around the detected person
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    # Put the label "Face (YOLO)" on the image
                    cv2.putText(frame, 'Face (YOLO)', (x1, y1-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

    # Show the image
    cv2.imshow('frame', frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and destroy all windows
videoCap.release()
cv2.destroyAllWindows()
